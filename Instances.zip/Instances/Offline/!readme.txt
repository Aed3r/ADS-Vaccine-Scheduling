In the offline part, instances of different scales and some special instances are created 

instance_offline_1 --- the number of patiens is 10
instance_offline_2 --- the number of patiens is 100
instance_offline_3 --- the number of patiens is 1000
instance_offline_4 --- the number of patiens is 10000
instance_offline_5 --- the empty-gap is 0
instance_offline_6 --- the patient delay is 0
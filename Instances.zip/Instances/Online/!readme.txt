This file discribed the features that each instance have.

instance_online_1 --- people's available time of first dose is very concentrated
instance_online_2 --- people's interval length is evry narrow
instance_online_3 --- interval length of all jobs is fixed
instance_online_4 --- patinet delay difference is large
instance_online_5 --- empyt-gap is 0